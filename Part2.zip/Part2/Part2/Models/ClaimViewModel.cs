﻿using System.ComponentModel.DataAnnotations;

namespace Part2.Models
{
    public class ClaimViewModel
    {

        public int Id { get; set; }

        [Required]
        [Display(Name = "Lecturer Name")]
        public string LecturerName { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime InvoiceDate { get; set; }

        public string DocumentPath { get; set; }

        public string ClaimStatus { get; set; }
        public decimal Total { get; set; }
        [Required(ErrorMessage = "Contractor Name is required")]
        [Display(Name = "Independent Contractor Name")]
        public string ContractorName { get; set; }

        [Required(ErrorMessage = "Address is required")]
        public string ContractorAddress { get; set; }

        [Required(ErrorMessage = "Contact Details are required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string ContractorContact { get; set; }

     

        [Required(ErrorMessage = "Invoice Number is required")]
        [Display(Name = "Invoice Number")]
        public string InvoiceNumber { get; set; }

        [Required(ErrorMessage = "Claim From date is required")]
        [DataType(DataType.Date)]
        public DateTime ClaimFrom { get; set; }

        [Required(ErrorMessage = "Claim To date is required")]
        [DataType(DataType.Date)]
        public DateTime ClaimTo { get; set; }

        [Required(ErrorMessage = "School Name is required")]
        public string SchoolName { get; set; }

        [Required(ErrorMessage = "School Address is required")]
        public string SchoolAddress { get; set; }

        [Required(ErrorMessage = "School City is required")]
        public string SchoolCity { get; set; }

        [Required(ErrorMessage = "School Telephone is required")]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string SchoolTel { get; set; }

        [Required(ErrorMessage = "School VAT Number is required")]
        public string SchoolVAT { get; set; }

        [Required(ErrorMessage = "Session is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Session must be a positive number")]
        public int Session { get; set; }

        [Required(ErrorMessage = "Module Code is required")]
        public string ModuleCode { get; set; }

        [Required(ErrorMessage = "Number of Groups is required")]
        [Range(1, int.MaxValue, ErrorMessage = "Number of Groups must be a positive number")]
        public int Groups { get; set; } // Change here to int

        [Display(Name = "Supporting Document")]
        public IFormFile Document { get; set; }
    }
}
