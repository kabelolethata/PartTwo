﻿namespace Part2.Models
{
    public class ClaimTrackingViewModel
    {
        public int ClaimId { get; set; }
        public string ContractorName { get; set; }
        public string ClaimStatus { get; set; }
       
        public DateTime SubmittedDate { get; set; } // This should not be nullable
        public DateTime? ApprovedDate { get; set; }
        public string ApprovedBy { get; set; }
    }
}

