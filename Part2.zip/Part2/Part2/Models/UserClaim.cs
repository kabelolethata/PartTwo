﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Part2.Models
{
    public class UserClaim
    {
        public int Id { get; set; }

        [Required]
        public string ContractorName { get; set; }

        public string ContractorAddress { get; set; }

        public string ContractorContact { get; set; }

        [DataType(DataType.Date)]
        public DateTime InvoiceDate { get; set; }

        public string InvoiceNumber { get; set; }

        [DataType(DataType.Date)]
        public DateTime ClaimFrom { get; set; }

        [DataType(DataType.Date)]
        public DateTime ClaimTo { get; set; }

        public string SchoolName { get; set; }

        public string SchoolAddress { get; set; }

        public string SchoolCity { get; set; }

        public string SchoolTel { get; set; }

        public string SchoolVAT { get; set; }

        public int Session { get; set; } // Updated to int
        public int Groups { get; set; } // Updated to int

        public string DocumentPath { get; set; }

        public string ClaimStatus { get; set; }
        public string ModuleCode { get; set; } // Added ModuleCode

        public string SubmittedBy { get; set; }

        public decimal Total { get; set; }

        public DateTime SubmittedDate { get; set; } = DateTime.Now; // Default to now

        public string LecturerName { get; set; } // Added LecturerName if needed
    }
}
