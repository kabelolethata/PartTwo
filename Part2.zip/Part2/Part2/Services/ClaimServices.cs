﻿using Microsoft.EntityFrameworkCore;
using Part2.Data;
using Part2.Models; // Ensure this is correct
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Part2.Services
{
    public class ClaimService
    {
        private readonly ApplicationDbContext _context;

        public ClaimService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<UserClaim>> GetClaimsForUserAsync(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                throw new ArgumentException("Username cannot be null or empty.", nameof(username));
            }

            // Ensure you're using the correct DbSet
            return await _context.UserClaims
                .Where(c => c.SubmittedBy == username)
                .ToListAsync();
        }

        public async Task<IEnumerable<UserClaim>> GetClaimsByStatusAsync(string status)
        {
            return await _context.UserClaims
                .Where(c => c.ClaimStatus == status)
                .ToListAsync();
        }

        public async Task<UserClaim> GetClaimByIdAsync(int id)
        {
            return await _context.UserClaims.FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task SaveClaimAsync(UserClaim claim)
        {
            await _context.UserClaims.AddAsync(claim);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateClaimAsync(UserClaim claim)
        {
            _context.UserClaims.Update(claim);
            await _context.SaveChangesAsync();
        }
    }
}
