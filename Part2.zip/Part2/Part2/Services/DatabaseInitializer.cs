﻿using Microsoft.AspNetCore.Identity;
using Part2.Data;

public static class DatabaseInitializer
{
    public static async Task Initialize(ApplicationDbContext context, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
    {
        await context.Database.MigrateAsync();

        if (!await roleManager.RoleExistsAsync("Admin"))
        {
            await roleManager.CreateAsync(new IdentityRole("Admin"));
        }
        if (!await roleManager.RoleExistsAsync("User"))
        {
            await roleManager.CreateAsync(new IdentityRole("User"));
        }

        var defaultUser = new IdentityUser { UserName = "admin@admin.com", Email = "admin@admin.com" };
        if (await userManager.FindByEmailAsync(defaultUser.Email) == null)
        {
            await userManager.CreateAsync(defaultUser, "Admin@123");
            await userManager.AddToRoleAsync(defaultUser, "Admin");
        }
    }
}
