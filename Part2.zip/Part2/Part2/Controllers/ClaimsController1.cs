﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Part2.Models;
using Part2.Services;

namespace Part2.Controllers
{
    [Authorize] // This will protect all actions in the controller
    public class ClaimsController : Controller
    {
        private readonly ClaimService _claimService;

        public ClaimsController(ClaimService claimService)
        {
            _claimService = claimService;
        }

        public IActionResult ApprovalClaims(string search, int? page)
        {
            // Your logic to retrieve claims
            var claims = _claimService.GetClaimsForApproval(search, page);
            return View(claims);
        }

        [HttpPost]
        public IActionResult SubmitClaim(ClaimViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Your logic to submit claims
                _claimService.SubmitClaim(model);
                TempData["SuccessMessage"] = "Claim submitted successfully!";
                return RedirectToAction("ApprovalClaims");
            }
            return View(model);
        }

        public IActionResult TrackClaims()
        {
            // Your logic to track claims
            var trackingData = _claimService.GetTrackingData(User.Identity.Name);
            return View(trackingData);
        }
    }
}
