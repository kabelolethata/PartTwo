using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Part2.Models;
using Part2.Services;
using Microsoft.AspNetCore.Authorization;
using System.Threading.Tasks;

namespace Part2.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ClaimService _claimService;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly UserManager<User> _userManager;

        public HomeController(ILogger<HomeController> logger, ClaimService claimService, IWebHostEnvironment webHostEnvironment, UserManager<User> userManager)
        {
            _logger = logger;
            _claimService = claimService;
            _webHostEnvironment = webHostEnvironment;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize]
        public IActionResult ProtectedAction()
        {
            return View();
        }

        [Authorize]
        public async Task<IActionResult> TrackClaims()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return RedirectToAction("Login", "Account");
            }
            var claims = await _claimService.GetClaimsForUserAsync(user.Id);
            return View(claims);
        }
        public IActionResult Privacy()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public IActionResult SubmitClaim()
        {
            return View(new ClaimViewModel());
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> SubmitClaim(ClaimViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = await _userManager.GetUserAsync(User);
                if (user == null)
                {
                    return RedirectToAction("Login", "Account");
                }
                try
                {
                    // Create a new claim object
                    var claim = new UserClaim
                    {
                        ContractorName = model.ContractorName,
                        ContractorAddress = model.ContractorAddress,
                        ContractorContact = model.ContractorContact,
                        InvoiceDate = model.InvoiceDate,
                        InvoiceNumber = model.InvoiceNumber,
                        ClaimFrom = model.ClaimFrom,
                        ClaimTo = model.ClaimTo,
                        SchoolName = model.SchoolName,
                        SchoolAddress = model.SchoolAddress,
                        SchoolCity = model.SchoolCity,
                        SchoolTel = model.SchoolTel,
                        SchoolVAT = model.SchoolVAT,
                        Session = model.Session,
                        ModuleCode = model.ModuleCode,
                        Groups = model.Groups,
                        ClaimStatus = "Pending",
                        SubmittedBy = User.Identity.Name,
                        Total = CalculateTotal(model)
                    };


                    // Save the uploaded document if any
                    if (model.Document != null && model.Document.Length > 0)
                    {
                        claim.DocumentPath = await SaveDocumentAsync(model.Document);
                    }
                    await _claimService.SaveClaimAsync(claim);
                    return RedirectToAction("TrackClaims");
                   // await _claimService.SaveClaimAsync(claim); // Save the claim to the database
                    //TempData["SuccessMessage"] = "Your claim has been submitted successfully!";
                    //return RedirectToAction("ClaimSubmissionSuccess");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error occurred while submitting claim");
                    ModelState.AddModelError("", "An error occurred while submitting your claim. Please try again.");
                }
            }

            return View(model); // Return to the view with the model to show validation errors
        }

        [Authorize(Roles = "Admin,Manager")]
        public async Task<IActionResult> ApprovalClaims()
        {
            var claims = await _claimService.GetClaimsByStatusAsync("Pending");
            return View(claims);
        }

        private decimal CalculateTotal(ClaimViewModel model)
        {
            decimal baseRate = 100; // Base rate per session
            return baseRate * model.Session * model.Groups; // Ensure model.Groups is an int
        }

        private async Task<string> SaveDocumentAsync(IFormFile file)
        {
            if (file == null || file.Length == 0)
                return null;

            var uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "uploads");
            if (!Directory.Exists(uploadsFolder))
                Directory.CreateDirectory(uploadsFolder);

            var uniqueFileName = Guid.NewGuid().ToString() + "_" + Path.GetFileName(file.FileName); // Use Path.GetFileName
            var filePath = Path.Combine(uploadsFolder, uniqueFileName);

            using (var fileStream = new FileStream(filePath, FileMode.Create))
            {
                await file.CopyToAsync(fileStream); // Save the file asynchronously
            }

            return uniqueFileName; // Return the file name for saving in the database
        }

        public IActionResult ClaimSubmissionSuccess()
        {
            return View(); // View to display after successful claim submission
        }

        [Authorize(Roles = "Admin, Manager")] // Only admins and managers can access this
        public async Task<IActionResult> ApprovalClaims(string search, int? page)
        {
            const int pageSize = 10; // Number of claims per page
            var claims = await _claimService.GetClaimsByStatusAsync("Pending"); // Fetch pending claims

            // Filter claims based on search input
            if (!string.IsNullOrWhiteSpace(search))
            {
                claims = claims.Where(c => c.SubmittedBy.Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();
            }

            // Implement pagination
            var totalClaims = claims.Count();
            var currentPage = page ?? 1;
            var claimsToDisplay = claims.Skip((currentPage - 1) * pageSize).Take(pageSize).ToList();

            // Pass the necessary data to the view
            ViewData["PrevPage"] = currentPage > 1 ? currentPage - 1 : (int?)null;
            ViewData["NextPage"] = claimsToDisplay.Count() == pageSize ? currentPage + 1 : (int?)null;

            return View(claimsToDisplay); // Return only the claims for the current page
        }

        [Authorize]
        public async Task<IActionResult> DownloadDocument(int id)
        {
            var claim = await _claimService.GetClaimByIdAsync(id);
            if (claim == null || string.IsNullOrEmpty(claim.DocumentPath))
            {
                return NotFound();
            }

            var filePath = Path.Combine(_webHostEnvironment.WebRootPath, "uploads", claim.DocumentPath);
            var fileBytes = await System.IO.File.ReadAllBytesAsync(filePath);
            return File(fileBytes, "application/octet-stream", claim.DocumentPath);
        }

        // Other actions remain unchanged...
    }
}
