﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Part2.Models;

namespace Part2.Data
{
    public class UserRepository
    {
        private readonly ApplicationDbContext _context;

        public UserRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        // Method to call the stored procedure
        public async Task<User> LoginUser(string username, string password)
        {
            var parameters = new[]
            {
            new SqlParameter("@Username", username),
            new SqlParameter("@Password", password)
        };

            var result = await _context.Users
                .FromSqlRaw("EXEC sp_LoginUser @Username, @Password", parameters)
                .FirstOrDefaultAsync();

            return result;
        }
    }
}
