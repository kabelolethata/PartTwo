﻿using Microsoft.EntityFrameworkCore;
using Part2.Models;


namespace Part2.Data;
public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<User> Users { get; set; } // Example entity
    // Add other DbSet properties for your models

  
       
        public DbSet<UserClaim> UserClaims { get; set; } // Use UserClaims for clarity

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();

            modelBuilder.Entity<User>().ToTable("Users");
            modelBuilder.Entity<UserClaim>().ToTable("UserClaims");
            // Ensure to map UserClaim to a table
    }
    }



